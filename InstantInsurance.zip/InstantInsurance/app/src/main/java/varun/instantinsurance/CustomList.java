package varun.instantinsurance;

/**
 * Created by Varun on 01-09-2016.
 */

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
public class CustomList extends ArrayAdapter<String>{

    public static Boolean[] Values ={false,false,false,false,false};
    private final Activity context;
    private final Integer[] imageId;
    private final String[] title;
    private final Integer[] pricetag;
    public CustomList(Activity context,
                      Integer[] imageId, String[] title,Integer[] pricetag) {
        super(context, R.layout.list_single, title);
        this.context = context;
        this.title = title;
        this.imageId = imageId;
        this.pricetag = pricetag;
    }
    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View rowView= inflater.inflate(R.layout.list_single, null, true);

        TextView txtTitle = (TextView) rowView.findViewById(R.id.titleappliance);
        TextView txtPricetag = (TextView) rowView.findViewById(R.id.pricetagappliance);

        ImageView imgappliance = (ImageView) rowView.findViewById(R.id.imgappliance);
        txtTitle.setText(title[position]);
        txtPricetag.setText("Prepare Now for $"+pricetag[position]);
        imgappliance.setImageResource(imageId[position]);

        //CheckBox chkappliance = (CheckBox) rowView.findViewById(R.id.chkappliance);
        //chkappliance.setId(position);
        ToggleButton TB1 = (ToggleButton) rowView.findViewById(R.id.toggleButton);
        final int rowPosition = position;
        TB1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // Save the state here
                Values[rowPosition]= isChecked;
                /*Toast.makeText(getContext(), isChecked ? "is on" : "is off",
                        Toast.LENGTH_LONG).show();*/
            }
        });

        return rowView;

    }
    public static Boolean[] getchecked(){

        return Values;
    }
}
