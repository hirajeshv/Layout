package varun.instantinsurance;

import java.util.ArrayList;

/**
 * Created by Varun on 01-09-2016.
 */
public class Data {
    String[] price={
            "340","200","100","124","200"
    };
    Integer[] imageId = {
            R.drawable.mac1,R.drawable.jbl,R.drawable.lcd,R.drawable.jbl,R.drawable.ipad
    };

    String[] title = {
            "Mac Book\n$"+price[0],"JBL\n$"+price[1],"LCD\n$"+price[2],"Oven\n$"+price[3],"Ipad\n$"+price[4]
    };
    Integer[] pricetag ={50,40,30,20,20};
    static ArrayList<String> fashionprice = new ArrayList<String>();
    static ArrayList<Integer> fashionImageId = new ArrayList<Integer>();
    static ArrayList<String> fashiontitle = new ArrayList<String>();


}
