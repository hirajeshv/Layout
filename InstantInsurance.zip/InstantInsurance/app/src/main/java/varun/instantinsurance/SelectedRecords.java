package varun.instantinsurance;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class SelectedRecords extends AppCompatActivity {
    ListView list;
    ArrayList<Integer> price;
    ArrayList<String[]> title;
    ArrayList<Integer[]> pricetag;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selected_records);

        SelectedList adapter2 = new SelectedList(SelectedRecords.this,Data.fashiontitle);

        list=(ListView)findViewById(R.id.selectedlist);
        list.setAdapter(adapter2);



    }

}
