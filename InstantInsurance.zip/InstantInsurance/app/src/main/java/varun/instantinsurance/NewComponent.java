package varun.instantinsurance;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class NewComponent extends AppCompatActivity {
    Button save;
    EditText title;
    EditText price;
    EditText model;
    Spinner type;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_component);
        title= (EditText) findViewById(R.id.editText);
        price= (EditText) findViewById(R.id.editText3);
        type= (Spinner) findViewById(R.id.spinnerpt);
        save= (Button) findViewById(R.id.save);
        save.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
               Data.fashiontitle.add(title.getText().toString() + price.getText().toString());
                Data.fashionprice.add(price.getText().toString());
               String typeval = type.getSelectedItem().toString();
                Toast.makeText(getApplicationContext(),"Details Saved",Toast.LENGTH_LONG).show();
            }
        });
    }

}
