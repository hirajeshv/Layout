package varun.instantinsurance;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.util.ArrayList;

public class ElectronicsActivity extends AppCompatActivity {
    ListView list;
    ToggleButton TB1;
    Button next,calculate;
    Boolean[] values;
    TextView total;
    int totalamount;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_electronics);
        Data data = new Data();
        final String[] price= data.price;
        Integer[] imageId =data.imageId;
        String[] title = data.title;
        final Integer[] pricetag = data.pricetag;
        CustomList adapter = new CustomList(ElectronicsActivity.this,imageId,title,pricetag);
        list=(ListView)findViewById(R.id.llist);
        list.setAdapter(adapter);
        //Get the Toggle Button Status
        total= (TextView) findViewById(R.id.lpricing_totalvalue);
        calculate = (Button) findViewById(R.id.lcalculate);
        calculate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                values=CustomList.getchecked();
                totalamount =0;
                if(values[0]){
                    totalamount = totalamount+pricetag[0];
                }
                if(values[1]){
                    totalamount = totalamount+pricetag[1];
                }
                if(values[2]){
                    totalamount = totalamount+pricetag[2];
                }
                if(values[3]){
                    totalamount = totalamount+pricetag[3];
                }
                if(values[4]){
                    totalamount = totalamount+pricetag[4];
                }
                total.setText("$"+totalamount);
            }
        });
        next = (Button) findViewById(R.id.lproceed);
        next.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                values=CustomList.getchecked();
                totalamount =0;
                if(values[0]){
                    totalamount = totalamount+pricetag[0];
                }
                if(values[1]){
                    totalamount = totalamount+pricetag[1];
                }
                if(values[2]){
                    totalamount = totalamount+pricetag[2];
                }
                if(values[3]){
                    totalamount = totalamount+pricetag[3];
                }
                if(values[4]){
                    totalamount = totalamount+pricetag[4];
                }
                total.setText("$"+totalamount);

                if(totalamount==0){
                    Toast.makeText(getApplicationContext(),"Please Select any Product",Toast.LENGTH_LONG).show();
                }
                else {
                    Intent intent = new Intent(ElectronicsActivity.this, Payments.class);
                    intent.putExtra("amount",totalamount);
                    startActivity(intent);
                }
            }
        });
    }

}
