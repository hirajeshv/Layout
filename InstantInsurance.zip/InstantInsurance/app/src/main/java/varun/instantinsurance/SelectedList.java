package varun.instantinsurance;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.util.ArrayList;

/**
 * Created by Varun on 01-09-2016.
 */
public class SelectedList extends ArrayAdapter<String> {

    private final Activity context;
    private final ArrayList<String> title;

    public SelectedList(Activity context,ArrayList<String> title) {
        super(context, R.layout.list_selected, title);
        this.context = context;
        this.title = title;

    }
    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View rowView= inflater.inflate(R.layout.list_single, null, true);

        TextView txtTitle = (TextView) rowView.findViewById(R.id.stitleappliance);
        TextView txtPricetag = (TextView) rowView.findViewById(R.id.spricetagappliance);

        ImageView imgappliance = (ImageView) rowView.findViewById(R.id.simgappliance);
        txtTitle.setText(title.get(position));
        txtPricetag.setText("$30");

        return rowView;

    }

}
